/*

Jonathan Song
CSCI 2270-200, Ashok Asawapatna

The point files compile and work and compile with the test1.cxx file. 
The point files and line files work and compile with the test2.cxx file.

Test 1 and Test 2 seem to be working well with the point and line files.

The ostream operator for line.cxx has been edited so it seems to be 
working correctly now. 

*/
