Jonathan Song
CSCI 2270-200, Ashok Basawapatna


The + and - operators work well with the simple numbers, but may have problems 
when the array size needs to be changed, particularly with the - operator.

The += operator leaves an invalid character at the last index.

The * operator seems to work for the most part. 
