Jonathan Song
CSCI 2270-200, Ashok Basawapatna

The remove function currently removes leaves fine, but also cuts off
the children of the target. 

The outputs are currently not exactly like the assignment, but the functions
basically work.
