Jonathan Song
CSCI 2270-200, Ashok Basawapatna

The maze.cxx and maze.h files compiles with the mainProgram and outputs 
the pre-condition and post-condition mazes.

The maze files work with the maze.txt file provided by Ashok, but 
have not been thoroughly tested with other mazes.
